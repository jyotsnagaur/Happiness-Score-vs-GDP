library(GGally)
library(shiny)
library(tidyverse)
library (ggplot2)
library(modelr)
library(dplyr)
library(caret)
library(car)
library(glmnet)
library(ISLR)
library(rgl)
library(shinythemes)
setwd("D:/ar/data")
d <- list() # creates a list
listcsv <- dir(pattern = "*.csv") # creates the list of all the csv files in the directory
for (k in 1:length(listcsv)){
  filename <- paste0('data',listcsv[k])
  d[[k]] <- read.csv(listcsv[k])
  assign(filename, d[[k]])
}


#####Correlation martix######
#——————————————————2018 anaylisis__________
data2018=na.omit(data2018.csv) #removed na value from data 
sum(is.na(data2018))
d2018=data2018[2:9]
lm2018=lm(Score~.,data = d2018[-1])
summary(lm2018)
#summary table showed only GDP, Social support, health.life.expectancy and freedom
#are significant variables thus removed others
#d2018 new data frame have been created, which only contain significant variables
d2018=data2018[3:7]
names(d2018)=c('Score','GDP','SS','HLE','Free')

#_________  2019___________
data2019=na.omit(data2019.csv)#removed na value from data
colnames(data2019)
sum(is.na(data2019))
d2019=data2019
lm2019=lm(Score~.,data = d2019[-c(1,2)])
summary(lm2019)
#summary table showed only GDP, Social support, health.life.expectancy and freedom
#are significant variables thus removed others
#d2018 new data frame have been created, which only contain significant variables
d2019=data2019[3:7]
names(d2019)=c('Score','GDP','SS','HLE','Free')

#_________  2020___________
#since variables used in this entire happiness level dataset are the same,
# thus  remain significant variables that found from both 2018 and 2019 data
data2020=na.omit(data2020.csv)#removed na value from data
colnames(data2020)
sum(is.na(data2020))
d2020=data2020[c(1,2,3,14,15,16,17)]
names(d2020)=c('Country','Region','Score','GDP','SS','HLE','Free')
d2020=data2020[c(3,14,15,16,17)]
names(d2020)=c('Score','GDP','SS','HLE','Free')

#_________  2021___________
data2021=na.omit(data2021.csv)#removed na value from data
colnames(data2021)
sum(is.na(data2021))
d2021=data2021[c(1,2,3,14,15,16,17)]
names(d2021)=c('Country','Region','Score','GDP','SS','HLE','Free')
d2021=data2021[c(3,14,15,16,17)]
names(d2021)=c('Score','GDP','SS','HLE','Free')


#_________Correlation Matrix for significant variable from year 2018 to 2021__

corr2018=ggcorr(d2018,nbreaks=8,
       label=TRUE,
       label_size=3,
       midpoint = 0,
       palette = "Spectral",
       color='BLACK')
corr2018
#the correlation matrix showed that happyiness score is high positive correalted
# with GDP, Sosical support and Healthy life expectancy. there is strong 
#correlation between GDP and Healthy life expectancy. By doing research, while 
#countries' GDP increase, people of that countries living standard could also 
# increase and thus healthy living style could be promoted, and thus this 
#strong correlationshis is reasonable.
corr2019=ggcorr(d2019,nbreaks=8,
       label=TRUE,
       label_size=3,
       midpoint = 0,
       palette = "Spectral",
       color='BLACK')
corr2019
#Same as 2018, 
# the correlation matrix showed that happyiness score is high positive correalted
# with GDP, Sosical support and Healthy life expectancy. there is strong 
#correlation between GDP and Healthy life expectancy. But this time, GDP not only 
# high correlated with Healthy life expectancy, it also high correalted with 
# social support. This can be casue by protential pendamic which happen at the end
# of 2019
corr2020=ggcorr(d2020,nbreaks=8,
       label=TRUE,
       label_size=3,
       midpoint = 0,
       palette = "Spectral",
       color='BLACK')
corr2020
#same as 2019
# the correlation matrix showed that happiness score is high positive correalted
# with GDP, Sosical support and Healthy life expectancy. there is strong 
#correlation between GDP and Healthy life expectancy. But this time, GDP not only 
# high correlated with Healthy life expectancy, it also high correlated with 
# social support. This can be cause by potential pandemic which throughout year2020
# since cov19 is a serious diease and until now still unsolved. Thus, we believe
# from 2019 to 2020, most people working from home and suffered from cov19 affection
# soscial support such as friend and family support were become their most important
# concent. When people feel down, a family member or friend who can stand by their side 
# can provide much help from both mental and pyhsical side.
corr2021=ggcorr(d2021,nbreaks=8,
       label=TRUE,
       label_size=3,
       midpoint = 0,
       palette = "Spectral",
       color='BLACK'
)
corr2021
#Same as previous, 
# the correlation matrix showed that happiness score is high positive correlated
# with GDP, Sosical support and Healthy life expectancy. there is strong 
#correlation between GDP and Healthy life expectancy. in year 2020, the cor relationship
# for GDP back to 2018, it again had strong positive correlation with HLE and followed
# by Social support. This could be cause by pandemic recovery effect.
#since most people suffered in year 2019, 2020 and even 2021. But in year 2021, 
# most countries promote injection and have better medical support around the 
# countries. Thus people's healthy concern get back.

c <- list() # creates a list
listcsv <- dir(pattern = "*.csv") # creates the list of all the csv files in the directory
for (k in 1:length(listcsv)){
  filename <- paste0('data',listcsv[k])
  c[[k]] <- read.csv(listcsv[k])
  assign(filename, c[[k]])
}

d2018=na.omit(data2018_1.csv)
d2019=na.omit(data2019_1.csv)
d2020=na.omit(data2020_1.csv)
d2021=na.omit(data2021_1.csv)
dnew=datanew.csv

######## A) SOCIAL #########################
#############################################
################################################

##### 1.) SOCIAL VS HAPPINESS 
#
ss <- ggplot(`data2021_1.csv`) +
  aes(x = Top20_Social, y = Top20_Score, color =Income ) +
  geom_point(
    shape = "circle",
    size = 3
  ) +
  labs(
    x = "Social Support",
    y = "Happiness Score",
    title = " The trend of Social Support and Hapiness Score of Top20 Happiest Countries",
    subtitle = "Year 2021"
  )  +
  theme_minimal()

ss

######## 2.) 4 YEARS SOCIAL VS HAPPINESS

ss_hp <- ggplot(data = datanew.csv, aes(x = Social,colour = income_class)) +
  geom_point(aes(y = Score),size=3)+
  xlab("Social Support") +
  ylab("Happiness Score") +
  ggtitle("The trend of Happiness Score with respect to Social Support of Top20 Happy countries")

ss_hp + facet_wrap(~Year)

### UAE####

######## B) FREEDOM ##############
#############################################
################################################

##### 1.) freedom VS HAPPINESS 

freedom <- ggplot(`data2021_1.csv`) +
  aes(x = Top20_Freedom, y = Top20_Score, color =Income ) +
  geom_point(
    shape = "circle",
    size = 3
  ) +
  labs(
    x = "Freedom of Speech",
    y = "Happiness Score",
    title = " The trend of Freedom of Speech and Hapiness Score of Top20 Happy Countries",
    subtitle = "Year 2021"
  )  +
  theme_minimal()

freedom

### COSTA RICA ###

######## 2.) 4 YEARS FREEDOM VS HAPPINESS

freedom_4years <- ggplot(data = datanew.csv, aes(x = Freedom,colour = income_class)) +
  geom_point(aes(y = Score),size=3)+
  xlab("Freedom of Speech") +
  ylab("Happiness Score") +
  ggtitle("The trend of Happiness Score with respect to Freedom of Speech of Top20 Happy countries")

freedom_4years + facet_wrap(~Year)

### COVID ### 

############### C.) HEALTH  ######################################
#######################################################################
#########################################################################



Cd2018=dataC2018.csv
Cd2019=dataC2019.csv
Cd2020=dataC2020.csv
Cd2021=dataC2021.csv
Cdnew=dataCnew.csv



######## 2.) 4 YEARS FREEDOM VS HAPPINESS

hle <- ggplot(data = dataCnew.csv, aes(x = Health,colour = income_class)) +
  geom_point(aes(y = Score),size=3)+
  xlab("Health Life Expectancy") +
  ylab("Happiness Score") +
  ggtitle(" The trend of Happiness Score with Health Life Expectancy of Top20 Healthiest countries")

hle + facet_wrap(~Year)

###########################
library(ggplot2)
library(tidyverse)


#-----------------------------digital payments in 2018-------------------------

mydata <- read.csv("D:/ar/data/graph4_digitalpay.csv")
mydata


Rplot = ggplot(mydata, aes(x=Country, y=Num, fill=dig2)) + 
  geom_bar(stat="identity", width=0.4, position=position_dodge(width=0.8))+
  scale_fill_brewer(palette="Accent")+
  coord_flip()+
  ylab("% Digital Payments made and not made by the citizens") +
  xlab("High income vs other countries") +
  ggtitle("The trend of digital payments made in 2018")


plot(Rplot)

#-----------------------------digital payments in 2021-------------------------
mydata2 <- read.csv("D:/ar/data/graph4_digitalpay2.csv")
mydata2


digitalpayment = ggplot(mydata2, aes(x=Country, y=Number, fill=dig)) + 
  geom_bar(stat="identity", width=0.4, position=position_dodge(width=0.8))+
  scale_fill_brewer(palette="Accent")+
  coord_flip()+
  ylab("% Digital Payments made and not made by the citizens") +
  xlab("High income vs other countries") +
  ggtitle("The trend of digital payments made in 2021")


plot(digitalpayment)

#-----------------------------US Hapi Score vs GDP-------------------------
mydata3 <- read_csv("D:/ar/data/graph3_US.csv")
mydata3

US_gdpvshs=ggplot(data = mydata3, aes(x = GDP_capita, colour = Year)) +
  geom_point(aes(y = Hap_Sc))+
  geom_line(aes(y = Hap_Sc))+
  xlab("GDP per capita") +
  ylab("Happiness Score") +
  ggtitle("The trend of GDP vs Happiness Score in US")
US_gdpvshs

#-----------------------------US Hapi Score vs Year-------------------------
US_yearvshs=ggplot(data = mydata3, aes(x = Year, colour = GDP_capita)) +
  geom_point(aes(y = Hap_Sc))+
  geom_line(aes(y = Hap_Sc))+
  xlab("Year") +
  ylab("Happiness Score") +
  ggtitle("The trend of Happiness Score from 2004 to 2021 in US")
US_yearvshs

#-----------------------------Hapi Score of Top 20 vs Year-------------------------
mydata4<- read_csv("D:/ar/data/gdpvshs.csv")
mydata4

p = ggplot(data = mydata4, aes(x = GDP_percap,colour = income_class)) +
  geom_point(aes(y = Hap_sc),size=0.01)+
  xlab("GDP per capita") +
  ylab("Happiness Score") +
  ggtitle("The trend of Happiness Score with respect to GDP per capita of Top20 Happy countries")

p + facet_wrap(~ Year)




library(shiny)
library(rsconnect)

df_new <- read.csv("country_list.csv")
df_new <- df_new[-1]
df_new
leaflet(df_new %>%
          dplyr::filter(
            happy_20 == 1
          )) %>%
  addTiles() %>%
  addMarkers(lat = ~latitudes, lng = ~longitudes)

ui <- fluidPage(
  titlePanel("Do higher income countries tend to be happier?"),
  (theme <- shinytheme("yeti")),
  navbarPage(
    title = "Happiness",
    tabPanel(
      title = "World",
      mainPanel(leafletOutput("mymap"))),
    tabPanel(
      title = "Correlation Matix",
      sidebarLayout(
        sidebarPanel(h2(strong(textOutput('corr',container = span)))
        )
        ,
        mainPanel(
          fluidRow(
            column(6,imageOutput("cor1")),
            column(6,imageOutput("cor2")),
            column(6,imageOutput( "cor3")),
            column(6,imageOutput( "cor4"))
            
          )
        )
      )),
    
    tabPanel(
      title = "GDP",
      sidebarLayout(
        sidebarPanel(
          selectInput("selection",
                      label = "Select",
                      choices = c(
                        "US GDP vs Happiness Score",
                        "US Happines from 2004 to 2021",
                        "Digital Payment of High Income and other countries",
                        "High Income Countries trend of Happiness Score"
                      )
          )
        ),
        mainPanel(
          h2(strong(textOutput("words", container = span))),
          imageOutput("digitalpayment_img"),
        )
      )
    ),
    
    tabPanel(title = "Social Support",
             sidebarLayout( 
               sidebarPanel( 
                 selectInput("sss", 
                             label = "Select",
                             choices=c('Social Support in Year 2021'
                                       ,'Social Support Comparision From 2018 to 2021'
                             )),width = 3),
               mainPanel (
                 h2(strong(textOutput('sswords',container = span))),
                 imageOutput("ss_img"),width = 9))),
    
    tabPanel(title = "Freedom",
             sidebarLayout( 
               sidebarPanel( 
                 selectInput("free", 
                             label = "Select",
                             choices=c('Freedom of Choice in Year 2021'
                                       ,'Freedom of Choice Comparision From 2018 to 2021'
                             )),width = 3),
               mainPanel (
                 h2(strong(textOutput('freewords',container = span))),
                 imageOutput("free_img"),width = 9))),
    
    tabPanel(title = "Health Life Expectancy",
             sidebarLayout( 
               sidebarPanel( 
                 selectInput("hle", 
                             label = "Select",
                             choices=c('Healthy Life Expectancy Comparision between 2020 and 2021'
                             )),width = 3),
               mainPanel (
                 h2(strong(textOutput('hlewords',container = span))),
                 imageOutput("hle_img"),width = 9))),
  )
)

server <- function(input, output, session) {
  output$mymap <- renderLeaflet({
    leaflet(df_new %>%
              dplyr::filter(
                happy_20 == 1
              )) %>%
      addTiles() %>%
      addMarkers(lat = ~latitudes, lng = ~longitudes)
  })
  output$corr = renderText({
    paste("Correlation matrix among Happiness Score (Score),
            Freedom (Free), Healthy Life Expectancy (HLE), GDP and Social Support (SS)")
  })
  output$cor1 <- renderImage({list(
    src = "corr2018.png", width = "90%",
    height = 400
  )},deleteFile=FALSE)
  output$cor2 <- renderImage({list(
    src = "corr2019.png", width = "100%",
    height = 500
  )},deleteFile=FALSE)
  output$cor3 <- renderImage({list(
    src = "corr2020.png", width = "100%",
    height = 500
  )},deleteFile=FALSE)
  output$cor4 <- renderImage({list(
    src = "corr2021.png", width = "100%",
    height = 500
  )},deleteFile=FALSE)
  #gdp
  output$words = renderText({
    if(input$selection=='US GDP vs Happiness Score'){
      paste("US happiness score vs GDP shows a declining trend")
    }
    else if(input$selection=='US Happines from 2004 to 2021'){
      paste("US happiness score changed by years")}
    else if(input$selection=='Digital Payment of High Income and other countries'){
      paste("Share of account owners using digital payment 
                                      has increased after pandemic, signalling- 
                                      hightened technology use which is an 
                                      aftereffect of increased GDP")}
    else if(input$selection=='High Income Countries trend of Happiness Score'){
      paste("With time the happiness score has increased for HI countries")}
  })
  
  
  output$digitalpayment_img = renderImage({
    if(input$selection=='US GDP vs Happiness Score'){
      list(src = "US_gdpvshs.png",width = "90%",
           height = 750)}
    else if(input$selection=='US Happines from 2004 to 2021'){
      list(src = "US_yearvshs.png",
           width = "90%",
           height = 750)}
    else if(input$selection=='Digital Payment of High Income and other countries'){
      list(src = "hd.png",
           width = "100%",
           height = 600)}
    else if(input$selection=='High Income Countries trend of Happiness Score'){
      list(src = "HIcountries_2.png",
           width = "90%",
           height = 750)}
  },deleteFile=FALSE)
  #ss
  output$sswords = renderText({
    if(input$sss=='Social Support in Year 2021'){
      paste('Costa Rica (OT) is one of the low income countries that joined 
              Top 20 Happiest countries list despite low social support score.')
    }
    else if(input$sss=='Social Support Comparision From 2018 to 2021'){
      paste('Year 2018 & 2019 has higher value of social support as compared to Year 2020 & 2021.​')}
  })
  
  
  output$ss_img = renderImage({
    if(input$sss=='Social Support in Year 2021'){
      list(src = "ss.png",width = "90%",
           height = 750)}
    else if(input$sss=='Social Support Comparision From 2018 to 2021'){
      list(src = "ss_hp.png",
           width = "90%",
           height = 600)}
  },deleteFile=FALSE)
  
  #free
  output$freewords = renderText({
    if(input$free=='Freedom of Choice in Year 2021'){
      paste("In 2021, Costa Rica (OT) being a low income country but comes in Top20 
                Happiest countries as it has a good Freedom of Speech Score.")
    }
    else if(input$free=='Freedom of Choice Comparision From 2018 to 2021'){
      paste('Year 2020 & 2021 has higher value in Freedom of Speech as 
          compared to Year 2018 & 2019, reason we believe is covid.')}
  })
  
  
  output$free_img = renderImage({
    if(input$free=='Freedom of Choice in Year 2021'){
      list(src = "freedom.png",width = "90%",
           height = 750)}
    else if(input$free=='Freedom of Choice Comparision From 2018 to 2021'){
      list(src = "freedom_4years.png",
           width = "90%",
           height = 750)}
    
  },deleteFile=FALSE)
  #hle 
  output$hlewords = renderText({
    if(input$hle=='Healthy Life Expectancy Comparision between 2020 and 2021'){
      paste('Year 2020 & 2021 show similar trends and have no such differences.')
    }
  })
  
  
  output$hle_img = renderImage({
    if(input$hle=='Healthy Life Expectancy Comparision between 2020 and 2021'){
      list(src = "hle.png",width = "90%",
           height = 750)}
  },deleteFile=FALSE)
}


shinyApp(ui = ui, server = server)

deployApp()









