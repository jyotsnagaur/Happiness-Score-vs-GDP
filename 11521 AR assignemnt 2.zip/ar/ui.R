#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)


df_new <- read.csv(file.choose())
df_new <- df_new[-1]
df_new
leaflet(df_new %>%
          dplyr::filter(
            happy_20 == 1
          )) %>%
  addTiles() %>%
  addMarkers(lat = ~latitudes, lng = ~longitudes)

ui <- fluidPage(
  titlePanel("Do higher income countries tend to be happier?"),
  leafletOutput("mymap"), (theme <- shinytheme("yeti")),
  navbarPage(
    title = "Happiness",
    tabPanel(
      title = "Main",
      sidebarLayout(
        sidebarPanel(h2(strong(textOutput('corr',container = span)))
        )
        ,
        mainPanel(
          fluidRow(
            column(6,imageOutput("cor1")),
            column(6,imageOutput("cor2")),
            column(6,imageOutput( "cor3")),
            column(6,imageOutput( "cor4"))
            
          )
        )
      )),
    
    tabPanel(
      title = "GDP",
      sidebarLayout(
        sidebarPanel(
          selectInput("selection",
                      label = "Select",
                      choices = c(
                        "US GDP vs Happiness Score",
                        "US Happines from 2004 to 2021",
                        "Digital Payment of High Income and other countries",
                        "High Income Countries trend of Happiness Score"
                      )
          )
        ),
        mainPanel(
          h2(strong(textOutput("words", container = span))),
          imageOutput("digitalpayment_img"),
        )
      )
    ),
    
    tabPanel(title = "Social Support",
             sidebarLayout( 
               sidebarPanel( 
                 selectInput("sss", 
                             label = "Select",
                             choices=c('Social Support in Year 2021'
                                       ,'Social Support Comparision From 2018 to 2021'
                             )),width = 3),
               mainPanel (
                 h2(strong(textOutput('sswords',container = span))),
                 imageOutput("ss_img"),width = 9))),
    
    tabPanel(title = "Freedom",
             sidebarLayout( 
               sidebarPanel( 
                 selectInput("free", 
                             label = "Select",
                             choices=c('Freedom of Choice in Year 2021'
                                       ,'Freedom of Choice Comparision From 2018 to 2021'
                             )),width = 3),
               mainPanel (
                 h2(strong(textOutput('freewords',container = span))),
                 imageOutput("free_img"),width = 9))),
    
    tabPanel(title = "Health Life Expectancy",
             sidebarLayout( 
               sidebarPanel( 
                 selectInput("hle", 
                             label = "Select",
                             choices=c('Healthy Life Expectancy Comparision between 2020 and 2021'
                             )),width = 3),
               mainPanel (
                 h2(strong(textOutput('hlewords',container = span))),
                 imageOutput("hle_img"),width = 9))),
  )
)

