#install.packages("shiny")
#install.packages("maps")
#install.packages("leaflet")


# Step1:load the libraries

library(shiny)
library(maps)
library(leaflet)
library(shinythemes)

#data("world.cities")


#world.cities
#head(world.cities)

#library(dplyr)
# df <- world.cities %>% group_by(country.etc) %>% summarise(latitudes=mean(lat), longitudes=mean(long), pop2=sum(pop))

# write.csv(df,file="output/country_list.csv")

df_new <- read.csv(file.choose())
df_new <- df_new[-1]
df_new
leaflet(df_new %>%
          dplyr::filter(
            happy_20 == 1
          )) %>%
  addTiles() %>%
  addMarkers(lat = ~latitudes, lng = ~longitudes)

setwd("E:/11521 AR/final")
ui <- fluidPage(
  titlePanel("Do higher income countries tend to be happier?"),
  leafletOutput("mymap"), (theme <- shinytheme("yeti")),
  navbarPage(
    title = "Happiness",
    tabPanel(
      title = "Main",
      sidebarLayout(
        sidebarPanel(h2(strong(textOutput('corr',container = span)))
                     )
        ,
      mainPanel(
        fluidRow(
          column(6,imageOutput("cor1")),
          column(6,imageOutput("cor2")),
          column(6,imageOutput( "cor3")),
          column(6,imageOutput( "cor4"))
          
        )
      )
    )),
    
    tabPanel(
      title = "GDP",
      sidebarLayout(
        sidebarPanel(
          selectInput("selection",
                      label = "Select",
                      choices = c(
                        "US GDP vs Happiness Score",
                        "US Happines from 2004 to 2021",
                        "Digital Payment of High Income and other countries",
                        "High Income Countries trend of Happiness Score"
                      )
          )
        ),
        mainPanel(
          h2(strong(textOutput("words", container = span))),
          imageOutput("digitalpayment_img"),
        )
      )
    ),
    
    tabPanel(title = "Social Support",
            sidebarLayout( 
              sidebarPanel( 
                 selectInput("sss", 
                     label = "Select",
                         choices=c('Social Support in Year 2021'
                                  ,'Social Support Comparision From 2018 to 2021'
                            )),width = 3),
              mainPanel (
                 h2(strong(textOutput('sswords',container = span))),
                 imageOutput("ss_img"),width = 9))),
    
    tabPanel(title = "Freedom",
       sidebarLayout( 
        sidebarPanel( 
          selectInput("free", 
            label = "Select",
             choices=c('Freedom of Choice in Year 2021'
                       ,'Freedom of Choice Comparision From 2018 to 2021'
                      )),width = 3),
        mainPanel (
          h2(strong(textOutput('freewords',container = span))),
          imageOutput("free_img"),width = 9))),
    
    tabPanel(title = "Health Life Expectancy",
      sidebarLayout( 
        sidebarPanel( 
          selectInput("hle", 
            label = "Select",
            choices=c('Healthy Life Expectancy Comparision between 2020 and 2021'
             )),width = 3),
       mainPanel (
                 h2(strong(textOutput('hlewords',container = span))),
                 imageOutput("hle_img"),width = 9))),
      )
)





#
# This is the server logic of a Shiny web application. You can run the
# application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)



server <- function(input, output, session) {
  output$mymap <- renderLeaflet({
    leaflet(df_new %>%
              dplyr::filter(
                happy_20 == 1
              )) %>%
      addTiles() %>%
      addMarkers(lat = ~latitudes, lng = ~longitudes)
  })
  output$corr = renderText({
    paste("Correlation matrix among Happiness Score (Score),
            Freedom (Free), Healthy Life Expectancy (HLE), GDP and Social Support (SS)")
  })
  output$cor1 <- renderImage({list(
    src = "corr2018.png", width = "100%",
    height = 500
  )},deleteFile=FALSE)
  output$cor2 <- renderImage({list(
    src = "corr2019.png", width = "100%",
    height = 500
  )},deleteFile=FALSE)
  output$cor3 <- renderImage({list(
    src = "corr2020.png", width = "100%",
    height = 500
  )},deleteFile=FALSE)
  output$cor4 <- renderImage({list(
    src = "corr2021.png", width = "100%",
    height = 500
  )},deleteFile=FALSE)
  #gdp
  output$words = renderText({
    if(input$selection=='US GDP vs Happiness Score'){
      paste("US happiness score vs GDP shows a declining trend")
    }
    else if(input$selection=='US Happines from 2004 to 2021'){
      paste("US happiness score changed by years")}
    else if(input$selection=='Digital Payment of High Income and other countries'){
      paste("Share of account owners using digital payment 
                                      has increased after pandemic, signalling- 
                                      hightened technology use which is an 
                                      aftereffect of increased GDP")}
    else if(input$selection=='High Income Countries trend of Happiness Score'){
      paste("With time the happiness score has increased for HI countries")}
  })
  
  
  output$digitalpayment_img = renderImage({
    if(input$selection=='US GDP vs Happiness Score'){
      list(src = "US_gdpvshs.png",width = "90%",
           height = 750)}
    else if(input$selection=='US Happines from 2004 to 2021'){
      list(src = "US_yearvshs.png",
           width = "90%",
           height = 750)}
    else if(input$selection=='Digital Payment of High Income and other countries'){
      list(src = "hd.png",
           width = "100%",
           height = 600)}
    else if(input$selection=='High Income Countries trend of Happiness Score'){
      list(src = "HIcountries_2.png",
           width = "90%",
           height = 750)}
  },deleteFile=FALSE)
  #ss
  output$sswords = renderText({
    if(input$sss=='Social Support in Year 2021'){
      paste('Costa Rica (OT) is one of the low income countries that joined 
              Top 20 Happiest countries list despite low social support score.')
    }
    else if(input$sss=='Social Support Comparision From 2018 to 2021'){
      paste('Year 2018 & 2019 has higher value of social support as compared to Year 2020 & 2021.​')}
  })
  
  
  output$ss_img = renderImage({
    if(input$sss=='Social Support in Year 2021'){
      list(src = "ss.png",width = "90%",
           height = 750)}
    else if(input$sss=='Social Support Comparision From 2018 to 2021'){
      list(src = "ss_hp.png",
           width = "90%",
           height = 750)}
  },deleteFile=FALSE)
  
  #free
  output$freewords = renderText({
    if(input$free=='Freedom of Choice in Year 2021'){
      paste("In 2021, Costa Rica (OT) being a low income country but comes in Top20 
                Happiest countries as it has a good Freedom of Speech Score.")
    }
    else if(input$free=='Freedom of Choice Comparision From 2018 to 2021'){
      paste('Year 2020 & 2021 has higher value in Freedom of Speech as 
          compared to Year 2018 & 2019, reason we believe is covid.')}
  })
  
  
  output$free_img = renderImage({
    if(input$free=='Freedom of Choice in Year 2021'){
      list(src = "freedom.png",width = "90%",
           height = 750)}
    else if(input$free=='Freedom of Choice Comparision From 2018 to 2021'){
      list(src = "freedom 4years.png",
           width = "90%",
           height = 750)}
    
  },deleteFile=FALSE)
  #hle 
  output$hlewords = renderText({
    if(input$hle=='Healthy Life Expectancy Comparision between 2020 and 2021'){
      paste('Year 2020 & 2021 show similar trends and have no such differences.')
    }
  })
  
  
  output$hle_img = renderImage({
    if(input$hle=='Healthy Life Expectancy Comparision between 2020 and 2021'){
      list(src = "HLE.png",width = "90%",
           height = 750)}
  },deleteFile=FALSE)
}


shinyApp(ui = ui, server = server)


